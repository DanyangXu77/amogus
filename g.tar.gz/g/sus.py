for i in range(0, 1000000000):
	pass
print("done")
