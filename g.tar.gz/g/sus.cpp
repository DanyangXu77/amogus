#include <iostream>
int main() {
    for (int i = 0; i < 1000000000; i++);
    std::cout << "done" << std::endl;
}